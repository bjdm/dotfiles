# Backgrounds
dark0='#101112'
dark0a='#121314'
dark1='#141617'
dark2='#191A1C'
dark3='#1D1F21'
dark4='#222426'

# Foregrounds
light0='#ebdbb2'
light1='#5B6066'
light2='#4F5459'
light3='#44484C'
light4='#393C40'

#Blue
neutral_blue='#0168D2'
muted_blue='#1966B7'
dark_blue='#0154AC'
light_blue='#1E7DDE'
pale_blue='#3688DE'

#Red
neutral_red='#B30009'
muted_red='#941A20'
dark_red='#870007'
light_red='#C81C24'
pale_red='#C8323A'

#Orange
neutral_orange='#FF9900'
muted_orange='#DD901D'
dark_orange='#D07C00'
light_orange='#FFA622'
pale_orange='#FFB13D'

#Yellow
neutral_yellow='#FFC500'
muted_yellow='#DDB11D'
dark_yellow='#D0A000'
light_yellow='#FFCC22'
pale_yellow='#FFD23D'

#Green
neutral_green='#0E9500'
muted_green='#1F7B16'
dark_green='#0B7100'
light_green='#27B319'
pale_green='#39B32D'

#Purple
neutral_purple='#9200A6'
muted_purple='#751D81'
dark_purple='#640073'
light_purple='#C02BD5'
pale_purple='#A949B6'

#Pink
neutral_pink='#E10097'
muted_pink='#AF2782'
dark_pink='#9B0068'
light_pink='#EA24A9'
pale_pink='#EA41B3'
