





Useful Resources:
http://zshwiki.org/home/
https://grml.org/zsh/
http://www.bash2zsh.com/zsh_refcard/refcard.pdf
https://reasoniamhere.com/2014/01/11/outrageously-useful-tips-to-master-your-z-shell/
http://strcat.de/zsh/#tipps
https://github.com/mika/zsh-pony
