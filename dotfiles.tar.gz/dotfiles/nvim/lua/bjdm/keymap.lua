vim.keymap.set('t', '<Esc>', '<C-\\><C-n>', { noremap = true, silent = true, nowait=true, desc = 'Exit to normal mode'})
vim.keymap.set('t', '<C-Esc>', '<Esc>', { noremap = true, silent = true, nowait=true, desc = 'Send escape to terminal'})

-- Open Nvim-Tree
vim.keymap.set('n', '<Leader>e', require('nvim-tree').open, { noremap = true, silent = true, nowait=true, desc = 'Move to next buffer in bufferlist'})

-- Buffer management
vim.keymap.set('n', '<C-b>l', vim.cmd('bnext'), { noremap = true, silent = true, nowait=true, desc = 'Move to next buffer in bufferlist'})
vim.keymap.set('n', '<C-b>h', vim.cmd('bprev'), { noremap = true, silent = true, nowait=true, desc = 'Move to previous buffer in bufferlist'})
vim.keymap.set('n', '<C-b>c', ':Bdelete<CR>', { noremap = true, silent = true, nowait=true, desc = 'Close buffer leaving window open'})
