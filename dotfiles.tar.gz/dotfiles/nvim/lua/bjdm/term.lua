vim.keymap.set('t', '<Esc>', '<C-\\><C-n>', { noremap = true, silent = true, nowait=true, desc = 'Exit to normal mode'})
