vim.g.tokyonight_style = night
vim.g.tokyonight_italic_functions = 1
vim.g.tokyonight_sidebars = { "qf", "terminal" }

-- Load the colour scheme
vim.cmd[[colorscheme tokyonight]]
