local lsp_config = require("lspconfig")

-- uncomment to debug
vim.lsp.set_log_level("info")
require("vim.lsp.log").set_format_func(vim.inspect)

-- Use a loop to conveniently call 'setup' on multiple servers and
-- map buffer local keybindings when the language server attaches
lsp_config.pylsp.setup{
	settings = {
		pylsp = {
			plugins = {
				pycodesylte = {
					ignore = {'W501'},
					maxLineLength = 88
				},
				pylint = {
					args = {
						'--ignore=E501,E231',
						'-',
					},
					enabled=true,
					debounce=200,
				}
			}
		}
	}
}

lsp_config.sumneko_lua.setup{
	settings = {
		Lua = {
			diagnostics = {
				-- Inject `vim` globals into language server
				globals = { 'vim' },
			},
		},
	},
}

lsp_config.tsserver.setup{}

lsp_config.clangd.setup{}

require('bjdm.lsp.null-ls')

