-- check packer is installed. Install it if not
require('bjdm')
