



ln -s ./zsh/zshrc.symlink ~/.zshrc
